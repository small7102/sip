/*
 * @Author: duanguang
 * @Date: 2022-04-26 17:09:56
 * @LastEditTime: 2022-04-26 17:11:01
 * @LastEditors: duanguang
 * @Description: 
 * @FilePath: /sip/src/pages/Call/index.js
 * 「扫去窗上的尘埃，才可以看到窗外的美景。」
 */
import Call from './Main/Main.js'
export default Call